# RandomXpy

A Python extension for getting RandomX hashes.
It's just a renaming of the project pyrx by jtgrassie.
Some own specific optimisations are possible

## Installation

```
pip install git+https://github.com/yoschii97/RandomXpy
```

## License

Please see the [LICENSE](./LICENSE) file.

[//]: # ( vim: set tw=80: )
